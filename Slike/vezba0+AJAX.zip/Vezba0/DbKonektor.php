<?php

require_once 'SistemPromenljive.php';

class DbKonektor extends SistemPromenljive{
	private $upit;
	private $link;
	
	public function __construct(){
		$sistemskep = SistemPromenljive::getSistemPromenljive();
		
		$host = $sistemskep['host'];
		$korisnik = $sistemskep['korisnik'];
		$lozinka = $sistemskep['lozinka'];
		$baza = $sistemskep['baza'];
		
		$this->link = mysql_connect($host, $korisnik, $lozinka);
		if( ($this->link) == false )
			throw new Exception("GRE�KA prilikom konekcije na server");
		$uspesno = mysql_select_db($baza, $this->link);
		if( !$uspesno )
			throw new Exception("GRE�KA prilikom selektovanja baze");
		
		mysql_set_charset("UTF8", $this->link);
	}
	
	public function getUpit(){
		return $this->upit;
	}
	
	public function getLink(){
		return $this->link;
	}
	
	public function upit($upitStr){
		$this->upit = $upitStr;
		$result = mysql_query($upitStr, $this->link);
		 
		if( !$result )
			throw new Exception( "GRE�KA>>".__CLASS__.".".__FUNCTION__."()</i></b><br/>".mysql_error($this->link) );
		
		return $result;
	}
	
	public  function fetchArray($result){
		return mysql_fetch_array($result);
	}
	
	public function fetchAssoc($result){
		return mysql_fetch_assoc($result);
	}
	
	public function fetchObject($result){
		return mysql_fetch_object($result);
	}
	
	public function freeResult($result){
		return mysql_free_result($result);
	}
	
	public function close(){
		return mysql_close($this->link);
	}
	
}

?>