<?php
	require_once 'DbKonektor.php';

	try{
	
		$db = new DbKonektor();
		
		$upit = "SELECT Host, User, Password FROM user";
		
		$result = $db->upit($upit);
		
		while($row = $db->fetchObject($result) )
			echo "Host : {$row->Host}<br/>Korisnik : {$row->User}<br/>Lozinka : {$row->Password}<br/><br/>";
		
	} catch (Exception $e) {
		echo $e->getMessage();
	}
	
?>