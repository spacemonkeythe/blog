<?php

class SistemPromenljive{
	private static $sistemPromenljive;
	
	public static function getSistemPromenljive(){
		$sistemPromenljive['host'] = 'localhost';
		$sistemPromenljive['korisnik'] = 'root';
		$sistemPromenljive['lozinka'] = '';
		$sistemPromenljive['baza'] = 'mysql';
		
		return $sistemPromenljive;
	}
	
}

?>