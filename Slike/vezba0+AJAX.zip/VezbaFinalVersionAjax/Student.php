<?php

	require_once("./includes/connectParams.php");
	require_once("./includes/myFunctions.php");

	
	/////////////////////////////////////////////////
	// lista studenata
	/////////////////////////////////////////////////
	if( !empty($_POST["getStudentLista"]) ){
		$connection = connectDB(host, user, pass, db);
		
		$query = "SELECT studentID, brIndeksa, ime, prezime, aktivan AS __aktivan__, 
	                      status.naziv AS statusNaziv, status.statusID AS __statusID__, 
	                      slikaURL AS __slikaURL__ 
                   FROM student JOIN status
				   ON student.statusID = status.statusID
				   ORDER BY studentID";
	
		$result = mysql_query($query, $connection);
		//broj kolona (polja) resultSet-a
		$numFields = mysql_num_fields($result);
		
		
		$table = "";
		//tabela se čuva i u numeričkom nizu čiji je svaki element asocijativni niz sa
		//ključevima koji su nazivi kolona tabele
		$tableDataProvider = array();
		
		
		//////////////////////
		//zaglavlje tabele
		///////////////////////
		$table .= "<tr>";
		for($i=0 ; $i<$numFields ; $i++){
			$fieldName = mysql_field_name($result, $i);
			$fieldNameLenght = strlen($fieldName);
			//ako ime kolone počinje i završava se sa  "__" ona neće biti prikazana u tabeli
			if( strpos($fieldName, "__") !== 0   ||   strrpos($fieldName, "__") !== $fieldNameLenght-2 )
				//imena kolona (polja) resultSet-a
				$table .= "<th>$fieldName</th>";
		}
		$table .= "</tr>";
		////////////////////////
		
		
		//////////////////////
		//sadržaj tabele
		///////////////////////
		$rowIndex = 0;
		while( $row = mysql_fetch_row($result) ){
			$table .= "<tr>";
			//svaki red tabele je asocijativni niz
			$tableDataProvider[$rowIndex] = array();
			for($i=0 ; $i<$numFields ; $i++){
				//ako ime kolone počinje i završava se sa  "__" ona neće biti prikazana u tabeli
				$fieldName = mysql_field_name($result, $i);
				$fieldNameLenght = strlen($fieldName);
				if( strpos($fieldName, "__") !== 0   ||   strrpos($fieldName, "__") !== $fieldNameLenght-2 )
					//funkcija mysql_fetch_row vraća svaki red resultSet-a kao numerički indeksiran niz
					$table .= "<td>".$row[$i]."</td>";
				//ključevi asocijativnog niza su imena kolona tabele
				$tableDataProvider[$rowIndex][$fieldName] = $row[$i];
			}
			$rowIndex++;
			
			//ako se ispisuje proširena tabela dodaju se dugmići za ažuriranje i brisanje
			//ovaj deo koda bi trebalo da se nalazi na klijentskoj strani u konstruktoru klase DataGrid
			$table .= "<td><input type='button' class='updateButton' name='update'></td>";
			$table .= "<td><input type='button' class='deleteButton' name='delete'></td>";
			
			$table .= "</tr>";
		}	
				   
				   
		//oslobađanje memorijskih resursa koje zauzima resultSet
		mysql_free_result($result);
		
		$response = new stdClass();
		$response->table = $table;
		//ova verzija servisa ne obrađuje greške
		$response->greska = new stdClass();
		$response->greska->uspesno = true; 
		$response->greska->poruka = "";
		$response->tableDataProvider = $tableDataProvider;
		//konverzija u JSON
		echo json_encode($response);
	}
	
	
	//////////////////////////////
	// unos novog studenta
	//////////////////////////////
	if( !empty($_POST['insertStudent']) ){
		$connection = connectDB(host, user, pass, db);
		
		//dekodovanje JSON stringa u objekat PHP generičke klase stdClass
		$student = json_decode($_POST['studentData']);
		
		$response = new stdClass();
		//greška
		$response->uspesno = true;
		$response->poruka = "";
		
		
		$insertIme = $student->ime;
		$insertPrezime = $student->prezime;
		$insertBrIndeksa = $student->brIndeksa;
		$insertStatusID = $student->statusID;
		$insertAktivan = $student->aktivan;
		
		//upiti za insert 
		$insertQuery = "INSERT INTO student (ime, prezime, brIndeksa, statusID, aktivan) VALUES(
						'$insertIme', '$insertPrezime', '$insertBrIndeksa', 
						$insertStatusID, $insertAktivan)";
		
		//unos novog studenta					
		if( !mysql_query($insertQuery, $connection) ){
			$poruka = "GREŠKA prilikom dodavanja novog studenta:\n\n".
							mysql_real_escape_string(mysql_error($connection));
			$response->uspesno = false;
			$response->poruka = $poruka;
		}
		
		
		//konvertovanje u JSON
		echo json_encode($response);
		
	}
	
	
	//////////////////////////////
	// ažuriranje studenta
	//////////////////////////////
	if( !empty($_POST['updateStudent']) ){
		$connection = connectDB(host, user, pass, db);
		
		//dekodovanje JSON stringa u objekat PHP generičke klase stdClass
		$student = json_decode($_POST['studentData']);
		
		$response = new stdClass();
		//greška
		$response->uspesno = true;
		$response->poruka = "";
		
		
		$updateStudentID = $student->studentID;
		$updateIme = $student->ime;
		$updatePrezime = $student->prezime;
		$updateBrIndeksa = $student->brIndeksa;
		$updateStatusID = $student->statusID;
		$updateAktivan = $student->aktivan;
		
		//upit za ažuriranje
		$updateQuery = "UPDATE student SET ime='$updateIme', prezime='$updatePrezime', 
								   brIndeksa='$updateBrIndeksa', statusID=$updateStatusID, 
								   aktivan=$updateAktivan 
								   WHERE studentID = $updateStudentID";
		
		//unos novog studenta					
		if( !mysql_query($updateQuery, $connection) ){
			$poruka = "GREŠKA prilikom ažuriranja studenta:\n\n".
							mysql_real_escape_string(mysql_error($connection));
			$response->uspesno = false;
			$response->poruka = $poruka;
		}
		
		
		//konvertovanje u JSON
		echo json_encode($response);
		
	}
	
	
	//////////////////////////////////
	// brisanje studenta
	/////////////////////////////////////
	if( !empty($_POST['deleteStudent']) ){
		$connection = connectDB(host, user, pass, db);
		
		//ID studenta za brisanje
		$deleteStudentID = $_POST['studentID'];
		
		$response = new stdClass();
		//greška
		$response->uspesno = true;
		$response->poruka = "";
		
		
		$deletQuery = "DELETE FROM student WHERE studentID=$deleteStudentID";
	
		//brisanje studenta					
		if( !mysql_query($deletQuery, $connection) ){
			$poruka = "GREŠKA prilikom brisanja studenta:\n\n".
							mysql_real_escape_string(mysql_error($connection));
			$response->uspesno = false;
			$response->poruka = $poruka;
		}
		
		
		//konvertovanje u JSON
		echo json_encode($response);
	}
	
	
	/////////////////////////////////////////////////
	// lista statusa
	/////////////////////////////////////////////////
	if( !empty($_POST["getStatusLista"]) ){
		$connection = connectDB(host, user, pass, db);
		
		$query = "SELECT statusID, naziv FROM status";
		$result = mysql_query($query, $connection);
		
		$select = array();
		while( $row = mysql_fetch_assoc($result) ){
			//svaka opcija SELECT elementa ima 
			//vrednost 'value' atributa jednaku vrednosti 'ID' kolone iz tabele baze i 
			//tekstualnu vrednost jednaku vrednosti kolone 'naziv' iz tabele baze
			$tmp = new stdClass();
			$tmp->value = $row["statusID"];
			$tmp->text = $row["naziv"];
			$select[] = $tmp;
		}

		//oslobađanje memorijskih resursa koje zauzima resultSet
		mysql_free_result($result);
		
		$response = new stdClass();
		$response->select = $select;
		//ova verzija servisa ne obrađuje greške
		$response->greska = new stdClass();
		$response->greska->uspesno = true;
		$response->greska->poruka = "";
		//konverzija u JSON
		echo json_encode($response);
	}
	

?>