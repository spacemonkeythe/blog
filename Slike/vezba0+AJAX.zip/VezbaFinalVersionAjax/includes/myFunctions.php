<?php
	
	//////////////////////////////////////////////////////////////////////
	// funkcija za konekciju na server i selektovanje baze podataka 
	/////////////////////////////////////////////////////////////////////
	function connectDB($host, $user, $pass, $db) {
		//konektovanje na MySQL server
		$link = mysql_connect($host, $user, $pass) or die("Neuspela konekcija");
		//selektovanje baze
		mysql_select_db($db) or die("Neuspelo selektovanje baze");
		//postavljanje klijentskog katakter seta
		mysql_set_charset("UTF8", $link);
		
		//funkcija vraća link konekcije
		return $link;
	}
	

?>