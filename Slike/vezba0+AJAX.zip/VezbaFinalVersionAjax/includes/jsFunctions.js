	
	
	/* "klasa" za upravljanje HTMl tabelom */
	function DataGrid(table, dataProvider) {
		//pridružena HTML tabela
		this.table = table;
		//interni niz HTML tabele (mora da ga generiše PHP)
		this.dataProvider = dataProvider;
		//selektovani red HTML tabele kao asocijativni niz
		this.selectedItem;
		//this nije dostupno u obrađivačima događaja
		var self = this;
		//dodaje se obrađivač događaja klika mišem bilo gde u tabeli
		this.table.onclick = function(event){
								//izvor događaja
								var element = event.target;
								//utvrđuje se red tabele na koji je kliknuto
								for(  ;  element.nodeName != 'TR'  ;  element = element.parentNode){ }
								//redni broj na koji je kliknuto
								var tableRowIndex = element.rowIndex;
								
								//utvrđuje se da li je kliknuto baš u ovoj tabeli
								if(element.parentNode.parentNode.id == table.id){
									//this nije više dostupan
									//indeksi počinju od 0
									self.selectedItem = self.dataProvider[tableRowIndex-1];
									
									var newEvent = null;
									//ako je kliknuto na dugme za ažuriranje kreira se događaj tipa 'update'
									//ako je kliknuto na deugme za brisanje kreira se događaj tipa 'delete'
									// IE 9+ ne podržava konstuktor klase Event, 
									//ranije verzije IE ne podžavaju ovakav model obrade događaja
									if(typeof Event == 'function') 
										newEvent = new Event(event.target.name); 
									else{
										newEvent = document.createEvent('Event');
										newEvent.initEvent(event.target.name, true, false);
									}
									
									//okidanje događaja
									this.dispatchEvent(newEvent);
								}
		};
		
		//bolje rešenje su 'setter' metode
		this.setTable = function(table) { this.table = table; };
		this.setDataProvider = function(dataProvider) { this.dataProvider = dataProvider; };
	}
	
	
	/* klasa za upravljanje PopUp div-ovima */
	function PopUpDiv(id){
		this.id = id;
		//div koji prekriva ceo ekran i omogućava modalnost
		this.blanket = null;
		//vrsta operacije
		this.mod = null;
		
		//this nije dostupno u funckijama
		var self = this;
		
		//prikazuje se popup div sa naslovom
		this.showPopUpDiv = function showPopUpDiv(modal, title, width, height) {
			var div = document.getElementById(self.id);
			//dimenzije ekrana
			var wHeight = window.innerHeight || 
						  document.documentElement.clientHeight || document.body.clientHeight;
			var wWidth = window.innerWidth || 
						 document.documentElement.clientWidth || document.body.clientWidth;
			
			//ako je ekran modalan treba prvo prikazati blanket
			if(modal){
				//kreira se novi div
				self.blanket = document.createElement("DIV");
				var blanketStyle = self.blanket.style;
				//kreirani div prekriva ceo ekran
				blanketStyle.position = "absolute";
				blanketStyle.top = "0px";
				blanketStyle.left = "0px";
				blanketStyle.width = wWidth+"px";
				blanketStyle.height = wHeight+"px";
				//dim efekat
				blanketStyle.opacity = "0.8";
				blanketStyle.backgroundColor = "white";
				//redosled slojeva ekrana
				blanketStyle.zIndex = "2";
				//prikazivanje kreiranog div-a
				document.body.appendChild(self.blanket);
			}
			
			var divStyle = div.style;
			//var divWidth = div.offsetWidth;
			//var divHeight = div.offsetHeight;
			divStyle.position = "absolute";
			divStyle.display = "block";
			divStyle.backgroundColor = "gray";
			//centriranje prozora
			divStyle.left = Math.round((wWidth - width)/2)+"px";
			divStyle.top = Math.round((wHeight - height)/2)+"px";
			//divStyle.top = "100px";
			//divStyle.left = "100px";
			divStyle.zIndex = "3";
			
			var popUpTitles = document.getElementsByName('popUpTitle');
			var popUpTitlesLenght = popUpTitles.length;
			for(var i=0 ; i<popUpTitlesLenght ; i++)
				if(popUpTitles[i].parentNode.parentNode.id == self.id)
					popUpTitles[i].innerHTML = title;
			
		}
		
		//uklanjanje popup div-a
		this.closePopUpDiv = function() {
			var div = document.getElementById(self.id);
			
			div.style.display = "none";
			//ako je popup div bio modalan treba ukloniti i blanket
			if(self.blanket != null)
				document.body.removeChild(self.blanket);
		}
	}
	
	
	/* funkcija za filtriranje tabele */
	function tableFilter(dataGrid, originalTableInnerHTML, originalTableDataProvider, searchField) {
		var searchText = searchField.value.toLowerCase();
		//filtrira se kopija orginalne tabele
		var table = dataGrid.table;
		//### IE ne dozvoljava izmenu innerHTML atributa tabele ###
		table.innerHTML = originalTableInnerHTML;
		//filtrira se kopija niza u koji je smeštena originalna tabela
		var tableDP = originalTableDataProvider;

		//filtrirana tabela
		var newInnerHTML = '';
		//filtrirani niz
		var newTableDataProvider = [];
		//redovi tabele
		var rows = table.childNodes[0].childNodes;
		//broj redova tabele
		var numRows = rows.length;

		//izlistavanje tabele (preskače se zaglavlje)
		for(var i=1 ; i<numRows ; i++){
			//red tabele
			var row = rows[i];
			//ćelije trenutnog reda
			var cells = row.childNodes;
			//broj kolona tabele
			var numColumns = cells.length;
			
			//izlistavanje reda tabele
			for(var j=0 ; j<numColumns ; j++){
				//ako se u ćeliji nalazi bilo šta osim teksta nodeName=null
				if( cells[j].childNodes[0].nodeName ){
					//sadržaj trenutne ćelije
					var cellContent = cells[j].innerHTML.toLowerCase();
					//ako ćelija sadrži tekst iz polja za pretragu 
					//treba red u kojem se nalazi uključiti u filtriranu tabelu
					if( cellContent.indexOf(searchText) != -1 ){
						//zbog zaglavlja indeksi počinju od 1
						newTableDataProvider.push( tableDP[i-1] );
						newInnerHTML += '<tr>'+row.innerHTML+'</tr>';
						break;
					}
				}
			}
		}
		
		//zaglavlje tabele
		var headerInnerHTML = rows[0].innerHTML;
		newInnerHTML = '<table>' + headerInnerHTML + newInnerHTML + '</table>';
	
		//ako je polje za pretragu prazno treba da se prikaže originalna tabela
		if( searchText.value == '' ){
			dataGrid.table.innerHTML = tableInnerHTML;
			dataGrid.setDataProvider(originalTableDataProvider);
		} else {
			dataGrid.table.innerHTML = newInnerHTML;
			dataGrid.setDataProvider(newTableDataProvider);
		}
			
	}	
	