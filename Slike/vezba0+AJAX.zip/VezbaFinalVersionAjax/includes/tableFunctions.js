	
	
	/* funkcija za popunjavanje forme za ažuriranje */
	function updateItem() {		
		//pronalaženje podataka za ažuriranje
		var updateStudentID = studentDataGrid.selectedItem.studentID;
		var updateBrIndeksa = studentDataGrid.selectedItem.brIndeksa;
		var updateIme = studentDataGrid.selectedItem.ime;
		var updatePrezime = studentDataGrid.selectedItem.prezime;
		var updateStatusID = studentDataGrid.selectedItem.__statusID__;
		var slikaURL = studentDataGrid.selectedItem.__slikaURL__;
		var aktivan = studentDataGrid.selectedItem.__aktivan__;
		//prikazuje modalni popup div za ažuriranje
		showStudentPopUp(2);

		//preslikavanje podataka u formu za ažuriranje
		document.getElementById('studentID').value = updateStudentID;
		document.getElementById('brIndeksa').value = updateBrIndeksa;
		document.getElementById('ime').value = updateIme;
		document.getElementById('prezime').value = updatePrezime;
		document.getElementById('status').value = updateStatusID;
		if( slikaURL )
			document.getElementById('slika').src = slikaURL;
		else
			document.getElementById('slika').src = './personalPhotos/default.png';
		if( aktivan == 1 )
			document.getElementById('aktivan').checked = true;
		else
			document.getElementById('aktivan').checked = false;
				
	}
	
	
	/* funkcija za pronalaženje studentID na čije dugme za brisanje se kliknulo */
	function deleteItem() {		
		//pronalaženje studentID, ime, prezime
		var studentID = studentDataGrid.selectedItem.studentID;
		var ime = studentDataGrid.selectedItem.ime;
		var prezime = studentDataGrid.selectedItem.prezime;
		//sa JavaScript confirm ekranom se traži potvrda za brisanje
		var odgovor = confirm('Da li želite da izbrišete studenta : ' + 
							   ime + ' ' + prezime + '?');
		//ako je korisnik potvrdio brisanje studenta treba izvršiti submit HTML forme
		if(odgovor){
			//inicijalizacija zahteva
			xmlhttpDelete.open("POST", "Student.php", true);
			//postavljanje zaglavlja
			xmlhttpDelete.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			//slanje zahteva
			xmlhttpDelete.send("deleteStudent=true&studentID="+studentID);
			
			
			//dodeljuje se osluškivač događaja za promenu stanja
			xmlhttpDelete.onreadystatechange = function(){
				//da li je odgovor spreman i da li je staus "OK"
				if( xmlhttpDelete.readyState == 4  &&  xmlhttpDelete.status == 200 ){
					var response = JSON.parse(xmlhttpDelete.responseText);
					
					//ako se nije desila greška ispisuje se poruka i učitava tabela
					if(response.uspesno){
						alert("Uspešno ste izbrisali studenta");
						getStudentLista();
					}
					else
						alert(response.poruka);
					
				}
				if( xmlhttpDelete.status == 404 )
					alert("Nepostojeći servis");
			}
		}
	}
	
	