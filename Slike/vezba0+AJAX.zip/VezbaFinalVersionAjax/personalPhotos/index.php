<?php
	echo "Nemate pravo pristupa";
?>